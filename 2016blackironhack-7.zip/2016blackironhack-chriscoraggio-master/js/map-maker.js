  var map;
  var markers = [];

  $(document).ready(function(){
      //create the map, import geojson and proportional circles based on population   

      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 14,
        center: new google.maps.LatLng(40.4237, -86.9212),
        mapTypeId: 'roadmap',
      });
  })


function addPointToMap(point_to_add){
  markers.push(new google.maps.Marker({
    position: new google.maps.LatLng(point_to_add.lat, point_to_add.lng),
    map
  }));
  refitMap();
}

function refitMap(){
  console.log(markers)
  const bounds = new google.maps.LatLngBounds();
  for (var i = 0; i < markers.length; i++) {
    bounds.extend(markers[i].getPosition());
  }

map.fitBounds(bounds);
}

function resetMarkers(){
  for (var i=0; i<markers.length; i++) {
     
        markers[i].setMap(null);
    }
  markers = [];
}