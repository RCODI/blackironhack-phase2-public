function fillInSpaces(names_of_cities){
	console.log("Filling in spaces")
	const spacing_number = 12 / names_of_cities.length;
	names_of_cities.forEach(function(name){
		console.log(name);
		$("#report-container").append("<div class=\" report-city col-md-" + spacing_number + "\">" + name + "</div>");
	});
}